# STRhub Verified: HipSTR (hipstr)

**Could not be determined.**

## As it is in the repository

**Step 1, the documented run: STRhub could not attempt the documented run.** The command was moved from the upstream image's working directory; this profile does not establish that change. The complete command and prerequisite must be established at the cited lines of this same pinned upstream commit; wiki text or a recipe label is not proof. input list cardinality is not changed to fit one available sample This evaluator cannot establish that the cited command reads the declared reference input; no config or input list was rewritten to make it do so. This evaluator has no proven installation profile for this recipe; no dependencies, compiler options or environment fixes may be supplied by STRhub. The command still names the repository's own file paths, not STRhub's sample. Running it would not be the reference-sample test. The limitation is ours. Nothing here is a finding about the tool.

**Verdict: Could not be determined.** The command was moved from the upstream image's working directory; this profile does not establish that change. The complete command and prerequisite must be established at the cited lines of this same pinned upstream commit; wiki text or a recipe label is not proof. input list cardinality is not changed to fit one available sample This evaluator cannot establish that the cited command reads the declared reference input; no config or input list was rewritten to make it do so. This evaluator has no proven installation profile for this recipe; no dependencies, compiler options or environment fixes may be supplied by STRhub. The command still names the repository's own file paths, not STRhub's sample. Running it would not be the reference-sample test.

Reached **Available**: the pinned public source exists.

### Gates

| Gate | Status | Meaning |
|---|---|---|
| Available | PASS | the pinned public source exists |
| Installs | — | the environment builds from source |
| Runs | — | it executes end-to-end without crashing |
| Runs + Expected IO | — | it produces a non-empty file in the declared format |
| Runs + Plausible output | — | its output looks like plausible genotype-bearing data (declared columns, DNA sequences, integer read counts, and enough recognisable forensic loci) |

### Planned command

The run step was skipped. This command was not executed by that step.

```
cd '/opt/tool' && touch /tmp/.strhub_mark && ( ./HipSTR --bams          run1.bam,run2.bam,run3.bam,run4.bam --fasta         genome.fa --regions       str_regions.bed --str-vcf       str_calls.vcf.gz ); rc=$?; find . -xdev -type f -newer /tmp/.strhub_mark -size +0 ! -path './.git/*' ! -path './proc/*' ! -path './sys/*' ! -path './dev/*' ! -path './data/*' ! -path '*/__pycache__/*' ! -name '*.pyc' ! -name '*.pyo' 2>/dev/null | head -500 | while IFS= read -r f; do mkdir -p "/data/out/$(dirname "$f")" && cp "$f" "/data/out/$f"; done; exit $rc
```

## Run details

- Source: `https://github.com/tfwillems/HipSTR` @ `12e989be4a8f9ab59f0c4c5da3784b82018cac82`
- Environment: ubuntu-22.04 (`Dockerfile`)
- Generated: 2026-11-12T21:12:42+00:00
- Upstream: The verified commit is 1 commit(s) behind `master`. That is context, not a fault: a pinned release is often meant to sit behind, and the attestation describes the commit it names.
- CI run: https://github.com/Tfronta/strhub-verified/actions/runs/43307658279

## Verification matrix

| Leg | Available | Result | Errors reported | Dataset |
|---|---|---|---|---|
| External data | N/A | N/A | — | None |
| Tool's own example | N/A | N/A | — | — |

## Evidence

What this run's configuration rests on, each item at the verified commit. Open any of them to check the claim it supports.
- Install method: [`Makefile`](https://github.com/tfwillems/HipSTR/blob/12e989be4a8f9ab59f0c4c5da3784b82018cac82/Makefile)
- Run command: [`README.md` line 69](https://github.com/tfwillems/HipSTR/blob/12e989be4a8f9ab59f0c4c5da3784b82018cac82/README.md#L69): `./HipSTR --bams          run1.bam,run2.bam,run3.bam,run4.bam`
- Example data: [`test/input/chr1_regions.bed`](https://github.com/tfwillems/HipSTR/blob/12e989be4a8f9ab59f0c4c5da3784b82018cac82/test/input/chr1_regions.bed)
- Example data: [`test/input/chr1_regions_v2.bed`](https://github.com/tfwillems/HipSTR/blob/12e989be4a8f9ab59f0c4c5da3784b82018cac82/test/input/chr1_regions_v2.bed)
- Example data: [`test/input/1kg.chr1.imputed.vcf.gz`](https://github.com/tfwillems/HipSTR/blob/12e989be4a8f9ab59f0c4c5da3784b82018cac82/test/input/1kg.chr1.imputed.vcf.gz)
- Documented input: [`README.md` line 69](https://github.com/tfwillems/HipSTR/blob/12e989be4a8f9ab59f0c4c5da3784b82018cac82/README.md#L69): `./HipSTR --bams          run1.bam,run2.bam,run3.bam,run4.bam`
- Platform advice: [`README.md` line 435](https://github.com/tfwillems/HipSTR/blob/12e989be4a8f9ab59f0c4c5da3784b82018cac82/README.md#L435): `We do not recommend running it on PacBio or Oxford Nanopore data, as the difference in error profiles will be problematic`

## What this run needed beyond the repository

The result above describes a run configured as follows. Anyone repeating it needs the same things.

- Test data: no sample from the repository was used, so a public reference sample stood in.
- A container environment, built from the tool's declared install steps rather than from a recipe the repository ships.

## Notes from reading the repository

Recorded automatically from the tool's public files when this run was configured. **Not verified by execution**, and not part of the gates above. Useful for what to check by hand.

- Environment: no proven installation profile; STRhub did not manufacture installation steps.
- Input: the README documents BAM (line 69); this plan selects STRhub's illumina-bam-hg38 reference data.
- Evaluator limitation: input list cardinality is not changed to fit one available sample.
- Run command: the README's own command, rewritten to STRhub's mounts; the capture wrapper is planned only if the procedure review passes.
- Loci: --regions str_regions.bed resolves to repository loci (test/input/chr1_regions.bed, test/input/chr1_regions_v2.bed) with 45 coordinate(s), none inside STRhub's reference sample.
- File: the documented command reads str_regions.bed (after --regions), which is neither in the repository nor among STRhub's data.

## Out of scope

This report does not evaluate any of the following:

- Genotype correctness or accuracy
- Concordance against known truth sets
- Sensitivity, specificity, or stutter performance
- Allele calling accuracy or forensic casework suitability
- Regulatory compliance or ISO accreditation
- Multi-laboratory or multi-dataset reproducibility

## Limitations

- Single reference dataset per input type
- Single containerized environment (Docker / ubuntu-22.04)
- No truth-set comparison or ground-truth genotypes
- No accuracy or concordance assessment
- No forensic validation of results
- Short-read limitations apply (very long STR alleles may not span reads)

## Scope (read this)

Assessment of documented execution in the stated environment and output format. Concerns reproducible execution only; no claim of accuracy, casework fitness, or regulatory validation.

This is **not** a claim that the genotypes are correct, nor that the tool is fit for casework or meets any regulatory standard. Concordance against known truth is out of scope.

Verified automatically, in a clean environment, on the tool's public source at the pinned commit. This is a record of what happened, not an endorsement by the tool's author.

